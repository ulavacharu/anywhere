import React from 'react'

function Error({error}) {
  return (
    <div>{error}
        <h1>HEHEHEH i f ed up</h1>
        <h1>Need to add warning thingies bye</h1>
    </div>
  )
}

export default Error